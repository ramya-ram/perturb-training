# Echo client program
PKG = "pr2_move_base"
import socket
import roslib
import roslib; roslib.load_manifest(PKG) 
import rospy
import actionlib
roslib.load_manifest('pr2_move_arms_ik')
import rospy
from pr2_move_arms_ik.srv import ExecuteCartesianIKTrajectory
from geometry_msgs.msg import Pose
from geometry_msgs.msg import Point
from geometry_msgs.msg import Twist
from geometry_msgs.msg import PoseStamped
from std_msgs.msg import Empty
from threading import Lock
from pr2_move_arms_ik.msg import PickPlaceCmd
from nav_msgs.msg import Odometry
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal, MoveBaseResult, MoveBaseFeedback, MoveBaseActionGoal

import rospy
import actionlib
from actionlib_msgs.msg import *
from pr2_controllers_msgs.msg import *
from geometry_msgs.msg import *

import time
import sys
import pdb
import tf
import math

class myClient:
	def __init__(self):
		print 'Starting Node...'
        	rospy.init_node("inspection_node")

		self.inspectState = True
		self.pauseState = False

		#Topics to know if the robot needs to pause
		self.pause_sub = rospy.Subscriber("pause_verification",Empty, self.setPauseStateTrue)
		self.unpause_sub = rospy.Subscriber("unpause_verification",Empty,self.setPauseStateFalse)

		#Topic to know when to verify
		self.start_sub = rospy.Subscriber("start_inspection",Empty, self.setInspectStateTrue)
		self.end_sub = rospy.Subscriber("end_inspection",Empty, self.setInspectStateFalse)

		#Topic to move the head
		self.head_client = actionlib.SimpleActionClient('/head_traj_controller/point_head_action', PointHeadAction)
		self.head_client.wait_for_server()

		print 'Started.'

	def setPauseStateTrue(self, msg):
		print 'Pausing'
		self.pauseState = True

	def setPauseStateFalse(self, msg):
		print 'Resuming'
		self.pauseState = False

	def setInspectStateTrue(self, msg):
		print 'Starting Inspection'
		self.inspectState = True

	def setInspectStateFalse(self, msg):
		print 'Ending Inspection'
		self.inspectState = False
	
	def run(self):
		print 'Ready to go...'
		t = 0
		while not rospy.is_shutdown():
			###   Simulate Inspection   ###

			while (self.pauseState == True) or (self.inspectState == False):
				time.sleep(0.005)

			#Scan part.
			g = PointHeadGoal()
			g.target.header.frame_id = 'base_link'
			g.target.point.x = .7
			if t % 4 == 0:
				g.target.point.y = -.2
				g.target.point.z = .95
			elif t % 4 == 1:
				g.target.point.y = -.4
				g.target.point.z = .95
			elif t % 4 == 2:
				g.target.point.y = -.2
				g.target.point.z = .65
			elif t % 4 == 3:
				g.target.point.y = -.4
				g.target.point.z = .65

			g.min_duration = rospy.Duration(1.0)
			self.head_client.send_goal(g)
			self.head_client.wait_for_result()

			t = t + 1
			time.sleep(.45)	
				

				

if __name__ == "__main__":
    my_client = myClient()
    my_client.run()
