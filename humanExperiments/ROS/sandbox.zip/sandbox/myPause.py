# Echo client program
PKG = "pr2_move_base"
import socket
import roslib
import roslib; roslib.load_manifest(PKG) 
import rospy
import actionlib
roslib.load_manifest('pr2_move_arms_ik')
import rospy
from pr2_move_arms_ik.srv import ExecuteCartesianIKTrajectory
from geometry_msgs.msg import Pose
from geometry_msgs.msg import Point
from geometry_msgs.msg import Twist
from geometry_msgs.msg import PoseStamped
from std_msgs.msg import Empty
from threading import Lock
from pr2_move_arms_ik.msg import PickPlaceCmd
from nav_msgs.msg import Odometry
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal, MoveBaseResult, MoveBaseFeedback, MoveBaseActionGoal

import time
import sys
import pdb
import tf
import math

class myClient:
	def __init__(self):
		print 'Starting Node...'
        	rospy.init_node("pause_node")

		print 'Creating Socket...'
		HOST = '128.31.7.69'    	# The remote host
		PORT = 12345             	# The same port as used by the server
		self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		print 'Socket created. Connecting to server...'		
		self.s.connect((HOST, PORT))
		print '...Connected to Server.'	

		#Topic to know if the robot needs to pause
		self.pause_pub = rospy.Publisher("pause_channel",Empty)
		self.unpause_pub = rospy.Publisher("unpause_channel",Empty)

		self.pause_inspection_pub = rospy.Publisher("pause_verification",Empty)
		self.unpause_inspection_pub = rospy.Publisher("unpause_verification",Empty)

		print 'Started.'

	def run(self):
		while not rospy.is_shutdown():

			print 'looping'

			#Read in from socket
			data = self.s.recv(1024)
			print 'Received', repr(data) 

			start_ind = data.find('{');
			end_ind = data.find('}');
			#If we received a task
			if data.find('exit') > -1:
				self.s.close();
				break;
			elif start_ind == -1 and end_ind == -1:
				continue	

			#Get the task name
			task = data[start_ind:end_ind+1]			
			
			empty = Empty()

			if task.find('Pause') > -1:
				print 'Pausing'
				self.pause_pub.publish(empty)
				self.pause_inspection_pub.publish(empty)
			elif task.find('Resume') > -1:
				print 'Resuming'
				self.unpause_pub.publish(empty)	
				self.unpause_inspection_pub.publish(empty)			

if __name__ == "__main__":
    my_client = myClient()
    my_client.run()

