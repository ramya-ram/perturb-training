# Echo client program
PKG = "pr2_move_base"
import socket
import roslib
import roslib; roslib.load_manifest(PKG) 
import rospy
import actionlib
roslib.load_manifest('pr2_move_arms_ik')
import rospy
from pr2_move_arms_ik.srv import ExecuteCartesianIKTrajectory
from geometry_msgs.msg import Pose
from geometry_msgs.msg import Point
from geometry_msgs.msg import Twist
from geometry_msgs.msg import PoseStamped
from std_msgs.msg import Empty
from threading import Lock
from pr2_move_arms_ik.msg import PickPlaceCmd
from nav_msgs.msg import Odometry
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal, MoveBaseResult, MoveBaseFeedback, MoveBaseActionGoal

import time
import sys
import pdb
import tf
import math

class myClient:
	def __init__(self):
		print 'Starting Node...'
        	rospy.init_node("pause_node")

		print 'Creating Socket...'
		HOST = '128.31.34.107'    	# The remote host
		PORT = 12345             # The same port as used by the server
		self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		print 'Socket created. Connecting to server...'		
		self.s.connect((HOST, PORT))
		print '...Connected to Server.'	

		#Topic to know if the robot needs to pause
		self.pause_pub = rospy.Publisher("pause_channel",Empty)
		self.unpause_pub = rospy.Publisher("unpause_channel",Empty)

		print 'Started.'

	def run(self):
		while not rospy.is_shutdown():

			#Read in from socket
			print 'Receiving...'
			data = self.s.recv(1024)
			print 'Received', repr(data) 

			print 'num tasks found: ',data.count('{')

			if data.find('exit') > -1:
				print 'Exiting'
				self.s.close();
				break;
			elif data.count('{') == 0:
				print 'Unreadable Message.'

			#If we received a task
			for i in range(0,data.count('{')):

				if i == 0:
					#Get the task name
					start_ind = data.find('{');
					end_ind = data.find('}');
					task = data[start_ind:end_ind+1]
					print 'Task: ',task
				else:
					last_ind = data.rfind('}')
					data = data[end_ind+1:last_ind+1]
					start_ind = data.find('{');
					end_ind = data.find('}');
					task = data[start_ind:end_ind+1]
					print 'Task: ',task	
		
				empty = Empty()
				if task.find('Pause') > -1:
					print 'Pausing'
					self.pause_pub.publish(empty)
				elif task.find('Resume') > -1:
					print 'Resuming'
					self.unpause_pub.publish(empty)	
				elif task.find(':0}') > -1:	
					###   Event: task start   ###

					#Start event immediately
					self.s.send(task)

					#Parse task information.
					y_g = 100
					y_g_green = .0
					y_g_blue = y_g_green+.45+.15
					y_g_yellow = y_g_blue+.45+.15

					if task.find('A') > -1:
						y_g=-0.30+y_g_green
					elif task.find('B') > -1:
						y_g=-0.15+y_g_green
					elif task.find('C1') > -1:
						y_g=0.0+y_g_green
					elif task.find('C2') > -1:
						y_g=0.15+y_g_green
					
					elif task.find('D') > -1:
						y_g=-0.30+y_g_yellow
					elif task.find('E') > -1:
						y_g=-0.15+y_g_yellow
					elif task.find('F') > -1:
						y_g=0.0+y_g_yellow
					elif task.find('G') > -1:
						y_g=0.15+y_g_yellow

					elif task.find('H') > -1:
						y_g=-0.30+y_g_blue
					elif task.find('I') > -1:
						y_g=-0.15+y_g_blue
					elif task.find('J1') > -1:
						y_g=0.0+y_g_blue
					elif task.find('J2') > -1:
						y_g=0.15+y_g_blue

					y_g_dropoff = 100					
					if task.find('A') > -1 or task.find('B') > -1 or task.find('C1') > -1 or task.find('C2') > -1:
						y_g_dropoff = -.2
					elif task.find('H') > -1 or task.find('I') > -1 or task.find('J1') > -1 or task.find('J2') > -1:
						y_g_dropoff = .1
					elif task.find('D') > -1 or task.find('E') > -1 or task.find('F') > -1 or task.find('G') > -1:
						y_g_dropoff = .4

					if y_g == 100 or y_g_dropoff == 100:
						continue


					#Send that you are starting
					self.s.send(task)

					#Move to pick-up location.

					#Pick part.

					#Verify part.


				elif task.find(':1}') > -1:	
					
					#Move to drop-off

					#Place part at drop-off
					
					#Acknowledge task completion.
					self.s.send(task)

if __name__ == "__main__":
    my_client = myClient()
    my_client.run()

