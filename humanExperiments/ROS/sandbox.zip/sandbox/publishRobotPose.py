# Echo client program
PKG = "pr2_move_base"
import socket
import roslib
import roslib; roslib.load_manifest(PKG) 
import rospy
import actionlib
roslib.load_manifest('pr2_move_arms_ik_lefty')
import rospy
from pr2_move_arms_ik.srv import ExecuteCartesianIKTrajectory
from geometry_msgs.msg import Pose
from geometry_msgs.msg import Point
from geometry_msgs.msg import Twist
from geometry_msgs.msg import PoseStamped
from std_msgs.msg import Empty
from threading import Lock
from pr2_move_arms_ik.msg import PickPlaceCmd
from nav_msgs.msg import Odometry

import time
import sys
import pdb
import tf
import math


class myClient:
	def __init__(self):
		print 'Starting Node...'

        	rospy.init_node("robot_pose_node")
		self.tf_listener = tf.TransformListener()
		self.base_pub = rospy.Publisher('my_robot_pose', Pose)
		self.gripper_pub = rospy.Publisher('my_robot_gripper_pose', Pose)
		#self.gripper_pub = rospy.Publisher('base_to_gripper', Pose)
		time.sleep(5) #give the transform listener time to get some frames
		print 'Started.'
	
	def run(self):
		counter = 0
		while not rospy.is_shutdown():

			self.tf_listener.waitForTransform('/map', '/base_link', rospy.Time(0),rospy.Duration(5))
            		(trans,rot) = self.tf_listener.lookupTransform('/map', '/base_link', rospy.Time(0))
			
			try:
				self.tf_listener.waitForTransform('/map', '/base_link', rospy.Time(0),rospy.Duration(5))
            			(trans,rot) = self.tf_listener.lookupTransform('/map', '/base_link', rospy.Time(0))
        		except (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException):
				print 'Exception'
            			continue

			#Base Pose
			my_pose = Pose()

			my_pose.position.x = round(trans[0],3)
			my_pose.position.y = round(trans[1],3)
			my_pose.position.z = 0
		
			my_pose.orientation.x = rot[0]
			my_pose.orientation.y = rot[1]
			my_pose.orientation.z = rot[2]
			my_pose.orientation.w = rot[3]


			#Convert quaternion to rotation about z-axis
			q0 = my_pose.orientation.x
			q1 = my_pose.orientation.y
			q2 = my_pose.orientation.z
			q3 = my_pose.orientation.w			
			w = round(math.atan2(2*(q0*q1+q2*q3),1-2*(q1**2+q2**2)),3)

			if counter == 10:
				self.base_pub.publish(my_pose)
				print ("Robot Pose = (%s,%s,%s)" % (my_pose.position.x,my_pose.position.y,w))
				counter = 0	
			else:
				counter = counter + 1	

			time.sleep(0.01)



if __name__ == "__main__":
    my_client = myClient()
    my_client.run()
