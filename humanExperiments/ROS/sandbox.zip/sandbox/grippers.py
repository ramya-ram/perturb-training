#!/usr/bin/env python
import roslib; 

roslib.load_manifest('actionlib')
roslib.load_manifest('pr2_controllers_msgs')

import rospy

import actionlib
import rospy
import time

from pr2_controllers_msgs.msg import *
from trajectory_msgs.msg import *
from actionlib_msgs.msg import *
from trajectory_msgs.msg import *



## RIGHT GRIPPER:

def openRightGripper() :
  print "Openning Right Gripper"
  rclient = actionlib.SimpleActionClient('r_gripper_controller/gripper_action', Pr2GripperCommandAction)
  rclient.wait_for_server()
  #open right gripper:
  rclient.send_goal(Pr2GripperCommandGoal(Pr2GripperCommand(position = 0.5, max_effort = -1)))
  rclient.wait_for_result()



def closeRightGripper() :
  print "Closing Right Gripper"
  rclient = actionlib.SimpleActionClient('r_gripper_controller/gripper_action', Pr2GripperCommandAction)
  rclient.wait_for_server()
  #close right gripper: 
  rclient.send_goal(Pr2GripperCommandGoal(Pr2GripperCommand(position = 0.0, max_effort = -1)))
  rclient.wait_for_result()


## LEFT GRIPPER:

def openLeftGripper() :
  print "Openning Left Gripper"
  lclient = actionlib.SimpleActionClient('l_gripper_controller/gripper_action', Pr2GripperCommandAction)
  lclient.wait_for_server()
  #open right gripper:
  lclient.send_goal(Pr2GripperCommandGoal(Pr2GripperCommand(position = 0.5, max_effort = -1)))
  lclient.wait_for_result()



def closeLeftGripper() :
  print "Closing Left Gripper"
  lclient = actionlib.SimpleActionClient('l_gripper_controller/gripper_action', Pr2GripperCommandAction)
  lclient.wait_for_server()
  #close right gripper: 
  lclient.send_goal(Pr2GripperCommandGoal(Pr2GripperCommand(position = 0.0, max_effort = -1)))
  lclient.wait_for_result()












if __name__ == '__main__':
    rospy.init_node('demo_pr2_motion')

    closeLeftGripper()
