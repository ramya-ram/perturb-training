#!/usr/bin/env python
import roslib; roslib.load_manifest('sound_play')
import rospy
from std_msgs.msg import String
from sound_play.msg import SoundRequest
from sound_play.libsoundplay import SoundClient

def callback(data):
    #rospy.loginfo(rospy.get_caller_id()+"I heard %s",data.data)
    voice = 'voice_kal_diphone'
    s = data.data
    print 'Saying: %s' % s
    print 'Voice: %s' % voice
    rospy.sleep(1)
    soundhandle = SoundClient()
    soundhandle.say(s,voice)
    
def soundListener():

    # in ROS, nodes are unique named. If two nodes with the same
    # node are launched, the previous one is kicked off. The 
    # anonymous=True flag means that rospy will choose a unique
    # name for our 'listener' node so that multiple listeners can
    # run simultaenously.
    rospy.init_node('say', anonymous=True)

    rospy.Subscriber("sound", String, callback)

    # spin() simply keeps python from exiting until this node is stopped
    rospy.spin()
        
if __name__ == '__main__':
    soundListener()
