#!/usr/bin/env python
import sys

if __name__ == '__main__':
    
    # Import after printing usage for speed.
    import roslib; roslib.load_manifest('sound_play')
    import rospy
    from sound_play.msg import SoundRequest
    from sound_play.libsoundplay import SoundClient
    
    # Ordered this way to minimize wait time.
    rospy.init_node('say', anonymous = True)
    soundhandle = SoundClient()
    rospy.sleep(1)

    voice = 'voice_kal_diphone'
    s = "Hi Ramya"
    print 'Saying: %s' % s
    print 'Voice: %s' % voice
    
    soundhandle.say(s,voice)
    rospy.sleep(1)
