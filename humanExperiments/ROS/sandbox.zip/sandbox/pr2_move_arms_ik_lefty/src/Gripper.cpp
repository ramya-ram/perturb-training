#include <ros/ros.h>
#include <pr2_controllers_msgs/Pr2GripperCommandAction.h>
#include <actionlib/client/simple_action_client.h>
#include <std_msgs/Empty.h>

using namespace pr2_controllers_msgs;
typedef actionlib::SimpleActionClient<Pr2GripperCommandAction> Client;

const int queue_size = 1;
const int rate = 50;

const double open_position = 0.08;
const double open_effort = -1.0;
const double close_position = 0.0;
const double close_effort = 50.0;

class Gripper {
    private:
        Client gripper; 
        
        ros::NodeHandle nh;
        ros::Subscriber open_sub;
        ros::Subscriber close_sub;
        
        ros::Publisher done_pub;
        
    public:
        Gripper(const char* open_topic, const char* close_topic, const char* done_topic) : gripper("l_gripper_controller/gripper_action", true) {
            ROS_INFO("Waiting for action server to start.");
            this->gripper.waitForServer();
            ROS_INFO("Connected to server");
            
            this->open_sub = nh.subscribe(open_topic, queue_size, &Gripper::open, this);
            this->close_sub = nh.subscribe(close_topic, queue_size, &Gripper::close, this);
            
            this->done_pub = nh.advertise<std_msgs::Empty>(done_topic, queue_size);
        }
        
        void activeCb() {
            ROS_INFO("Goal active...");
        }
        
        void feedbackCb(const Pr2GripperCommandFeedbackConstPtr& feedback) {
            ROS_INFO("In feedback...");
        }
        
        void doneCb(const actionlib::SimpleClientGoalState& state, const Pr2GripperCommandResultConstPtr& result) {
            bool success = (state == actionlib::SimpleClientGoalState::SUCCEEDED);
            
            if (success) 
                ROS_INFO("The gripper succeeded!");
            else
                ROS_INFO("The gripper failed."); 
                
            std_msgs::Empty msg;
            done_pub.publish(msg);
        }
        
        void open(const std_msgs::Empty msg) {
            Pr2GripperCommandGoal open;
            open.command.position = open_position;
            open.command.max_effort = open_effort;
            
            ROS_INFO("Sending open goal");
            gripper.sendGoal(open, 
                             boost::bind(&Gripper::doneCb, this, _1, _2),
                             boost::bind(&Gripper::activeCb, this), 
                             boost::bind(&Gripper::feedbackCb, this, _1));    
        }
        
        void close(const std_msgs::Empty msg) {
            Pr2GripperCommandGoal close;
            close.command.position = close_position;
            close.command.max_effort = close_effort;
            
            ROS_INFO("Sending close goal");
            gripper.sendGoal(close, 
                             boost::bind(&Gripper::doneCb, this, _1, _2),
                             boost::bind(&Gripper::activeCb, this), 
                             boost::bind(&Gripper::feedbackCb, this, _1));    
        }
        
        void run() {
            ros::Rate loop_rate(rate);
    
            while (ros::ok()) {
                ros::spinOnce();
                loop_rate.sleep();
            }
        }
};

int main(int argc, char **argv) {
    ros::init(argc, argv, "move_left_gripper");
	Gripper gripper("open", "close", "gripper_done");
	gripper.run();
}
