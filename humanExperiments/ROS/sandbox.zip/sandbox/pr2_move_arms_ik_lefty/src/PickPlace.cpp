
#include <ros/ros.h>
#include <geometry_msgs/Pose.h>
#include <std_msgs/Empty.h>
#include <pr2_move_arms_ik/PickPlaceCmd.h>

const int queue_size = 1;
const int rate = 50;
const double x_dist = 0.2;
const double z_dist = 0.2;

// Pick: DONE -> POSITION_TO_PICK -> XXX(OPEN_GRIPPER)XXX -> MOVE_FORWARD -> CLOSE_GRIPPER -> TAKE -> DONE
// Place: DONE -> POSITION_TO_PLACE -> OPEN_GRIPPER -> MOVE_BACK -> XXX(CLOSE_GRIPPER)XXX -> DONE
enum PickPlaceState {
    PICK,
    PLACE,
    NONE,
    POSITION_TO_PICK,
    POSITION_TO_PLACE,
    OPEN_GRIPPER,
    MOVE_FORWARD,
    MOVE_BACKWARD,
    CLOSE_GRIPPER,
    TAKE,
    DONE
};

class PickPlace {
    private:
        ros::NodeHandle nh;
        
        // publishers for commands to arm and gripper
        ros::Publisher pose_pub;
        ros::Publisher open_pub;
        ros::Publisher close_pub;
        
	// publishers to signal completion
        ros::Publisher done_pub;

        // sub for external command
        ros::Subscriber pickplace_sub;
        // sub for feedback from arm
        ros::Subscriber arm_sub;
        // sub for feedback fron gripper
        ros::Subscriber gripper_sub;
        
        PickPlaceState super_state;
        PickPlaceState state;
        
        geometry_msgs::Pose pickplace_pose;
        
    public:
        PickPlace(const char* pose_topic, const char* open_topic, const char* close_topic, const char* pickplace_topic, const char* arm_done_topic, const char* gripper_done_topic, const char* pickplace_done_topic) {

            this->pose_pub = nh.advertise<geometry_msgs::Pose>(pose_topic, queue_size);
            this->open_pub = nh.advertise<std_msgs::Empty>(open_topic, queue_size);
            this->close_pub = nh.advertise<std_msgs::Empty>(close_topic, queue_size);
            this->done_pub = nh.advertise<std_msgs::Empty>(pickplace_done_topic, queue_size);
            
	    this->pickplace_sub = nh.subscribe(pickplace_topic, queue_size, &PickPlace::pickplace, this);
            this->arm_sub = nh.subscribe(arm_done_topic, queue_size, &PickPlace::armDone, this);
            this->gripper_sub = nh.subscribe(gripper_done_topic, queue_size, &PickPlace::gripperDone, this);
            
            this->super_state = NONE;
            this->state = DONE;
            
            ROS_INFO("State: DONE");
        }
        
        void pickplace(const pr2_move_arms_ik::PickPlaceCmd msg) {
            geometry_msgs::Pose pose;
                    
            if (super_state == NONE && state == DONE) {
                if (msg.cmd == "pick") {
                    super_state = PICK;
                    state = POSITION_TO_PICK;
                    
                    pose.position.x = msg.pose.position.x - x_dist;
                    
                    ROS_INFO("State: POSITION_TO_PICK");
                }
                else if (msg.cmd == "place") {
                    super_state = PLACE;
                    state = POSITION_TO_PLACE;
                    
                    pose.position.x = msg.pose.position.x;
                    
                    ROS_INFO("State: POSITION_TO_PLACE");
                }
                
                pose.position.y = msg.pose.position.y;
                pose.position.z = msg.pose.position.z;
                    
                pose.orientation.x = 0.0;
                pose.orientation.y = 0.0;
                pose.orientation.z = 0.0;
                pose.orientation.w = 1.0;
                    
                pickplace_pose = pose;
                    
                pose_pub.publish(pose);
            }
        }
        
        void armDone(const std_msgs::Empty msg) {
            std_msgs::Empty empty;
        
            if (state == POSITION_TO_PLACE) { //state == POSITION_TO_PICK || ) {
                state = OPEN_GRIPPER;
                
                open_pub.publish(empty);
                
                ROS_INFO("State: OPEN_GRIPPER");
	    } else if (state == POSITION_TO_PICK) {
                state = MOVE_FORWARD;
                
                pickplace_pose.position.x += x_dist;
                pose_pub.publish(pickplace_pose);
                
                ROS_INFO("State: MOVE_FORWARD");
            } else if (state == MOVE_FORWARD){// || state == MOVE_BACKWARD) {
                state = CLOSE_GRIPPER;
                
                close_pub.publish(empty);
                
                ROS_INFO("State: CLOSE_GRIPPER");
            } else if (state == MOVE_BACKWARD) {
                super_state = NONE;
                state = DONE;    

		done_pub.publish(empty);
                
                ROS_INFO("State: DONE");
	    } else if (state == TAKE) {
	        super_state = NONE;
                state = DONE;    
                
		done_pub.publish(empty);
                
                ROS_INFO("State: DONE");	
	   }
        }
        
        void gripperDone(const std_msgs::Empty msg) {
        std_msgs::Empty empty;

            if (super_state == PICK && state == OPEN_GRIPPER) {
                state = MOVE_FORWARD;
                
                pickplace_pose.position.x += x_dist;
                pose_pub.publish(pickplace_pose);
                
                ROS_INFO("State: MOVE_FORWARD");
            }
            else if (super_state == PLACE && state == OPEN_GRIPPER) {
                state = MOVE_BACKWARD;
                
                pickplace_pose.position.x -= x_dist;
                pickplace_pose.position.z += z_dist;
                pose_pub.publish(pickplace_pose);
                
                ROS_INFO("State: MOVE_BACKWARD");
            }
            else if (super_state == PLACE && state == CLOSE_GRIPPER) {
                super_state = NONE;
                state = DONE;    

		done_pub.publish(empty);
                
                ROS_INFO("State: DONE");
            }
	    else if (super_state == PICK && state == CLOSE_GRIPPER) { 
		state = TAKE;

		pickplace_pose.position.x -= x_dist;
		pickplace_pose.position.z += z_dist;
                pose_pub.publish(pickplace_pose);

		ROS_INFO("State: Take");
	    }
        }
        
        void run() {
            ros::Rate loop_rate(rate);
    
            while (ros::ok()) {
                ros::spinOnce();
                loop_rate.sleep();
            }
        }
};

int main(int argc, char **argv) {
    ros::init(argc, argv, "pick_place");
	PickPlace pickplace("goal","open", "close","pickplace","arm_done","gripper_done","pickplace_done");
	pickplace.run();
}
