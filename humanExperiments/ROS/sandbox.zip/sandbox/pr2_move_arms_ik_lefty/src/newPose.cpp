#include <ros/ros.h>
#include <geometry_msgs/Pose.h>
#include <stdlib.h>

int main(int argc, char** argv) {
    ros::init (argc, argv, "new_pose_node");
    ros::NodeHandle nh;
    
    ros::Publisher pose_pub = nh.advertise<geometry_msgs::Pose>("goal", 1);
    
    geometry_msgs::Pose pose;
    pose.position.x = atof(argv[1]);
    pose.position.y = atof(argv[2]);
    pose.position.z = atof(argv[3]);
    ROS_INFO("Goal: %f %f %f", atof(argv[1]), atof(argv[2]), atof(argv[3]));

    pose.orientation.x = 0.0;
    pose.orientation.y = 0.0;
    pose.orientation.z = 0.0;
    pose.orientation.w = 1.0;
    
    ros::Rate poll_rate(100);
    while (pose_pub.getNumSubscribers() == 0)
        poll_rate.sleep();
        
    if (nh.ok()) {
        pose_pub.publish(pose);
        ros::spinOnce();
    }
    
    ros::shutdown();
}
