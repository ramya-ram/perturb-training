#include <ros/ros.h>
#include <pr2_move_arms_ik/PickPlaceCmd.h>
#include <stdlib.h>

int main(int argc, char** argv) {
    ros::init (argc, argv, "pick_place_pose");
    ros::NodeHandle nh;
    
    ros::Publisher pose_pub = nh.advertise<pr2_move_arms_ik::PickPlaceCmd>("pickplace", 1);
    
    pr2_move_arms_ik::PickPlaceCmd cmd;
    cmd.cmd = argv[1];
    
    cmd.pose.position.x = atof(argv[2]);
    cmd.pose.position.y = atof(argv[3]);
    cmd.pose.position.z = atof(argv[4]);
    ROS_INFO("Goal: %s %f %f %f", argv[1], atof(argv[2]), atof(argv[3]), atof(argv[4]));

    cmd.pose.orientation.x = 0.0;
    cmd.pose.orientation.y = 0.0;
    cmd.pose.orientation.z = 0.0;
    cmd.pose.orientation.w = 1.0;
    
    ros::Rate poll_rate(100);
    while (pose_pub.getNumSubscribers() == 0)
        poll_rate.sleep();
        
    if (nh.ok()) {
        pose_pub.publish(cmd);
        ros::spinOnce();
    }
    
    ros::shutdown();
}
