#!/usr/bin/env python
import roslib
roslib.load_manifest('pr2_move_arms_ik_lefty')
import rospy
from pr2_move_arms_ik.srv import ExecuteCartesianIKTrajectory
from geometry_msgs.msg import Pose
from std_msgs.msg import Empty
from threading import Lock
import time
import sys
import pdb
import tf

class MoveArm:
    def __init__(self, goal_topic, done_topic):
        rospy.init_node("move_arm_node")
        print "Starting node"
        
        self.tf_listener = tf.TransformListener()
        time.sleep(.5) #give the transform listener time to get some frames
        
        self.goal_sub = rospy.Subscriber(goal_topic, Pose, self.setPose, queue_size=1)
        self.done_pub = rospy.Publisher(done_topic, Empty)
        
        self.m_goal = Lock()
        self.goal = None
        
    def setPose(self, msg):
        print "Received pose"
        with self.m_goal:
            if self.goal == None:
                self.goal = msg
                
    def call_execute_cartesian_ik_trajectory(self, frame, positions, orientations):
        rospy.wait_for_service("execute_cartesian_ik_trajectory")

        #fill in the header (don't need seq)
        header = rospy.Header()
        header.frame_id = frame
        header.stamp = rospy.get_rostime()

        #fill in the poses
        poses = []
        for (position, orientation) in zip(positions, orientations):
            pose = Pose()
            pose.position.x = position[0]
            pose.position.y = position[1]
            pose.position.z = position[2]
            pose.orientation.x = orientation[0]
            pose.orientation.y = orientation[1]
            pose.orientation.z = orientation[2]
            pose.orientation.w = orientation[3]
            poses.append(pose)

        #call the service to execute the trajectory
        print "calling execute_cartesian_ik_trajectory"
        try:
            s = rospy.ServiceProxy("execute_cartesian_ik_trajectory", ExecuteCartesianIKTrajectory)
            resp = s(header, poses)
        except rospy.ServiceException, e:
            print "error when calling execute_cartesian_ik_trajectory: %s"%e
            return 0
        return resp.success

    def pplist(self, list):
        return ' '.join(['%2.3f'%x for x in list])
        
    def run(self):
        while not rospy.is_shutdown():
            position = None
            
            with self.m_goal:
                if self.goal != None:
                    print "Setting Position"
                    position = [[self.goal.position.x, self.goal.position.y, self.goal.position.z]]
                    orientation = [[self.goal.orientation.x, self.goal.orientation.y, self.goal.orientation.z, self.goal.orientation.w]]
                    self.goal = None
                      
            if position != None:
               success = self.call_execute_cartesian_ik_trajectory("/base_link", position, orientation)
            
               #check the final pose
               #(trans, rot) = self.tf_listener.lookupTransform('base_link', 'r_wrist_roll_link', rospy.get_rostime())
               #print "end Cartesian pose: trans", self.pplist(trans), "rot", self.pplist(rot)

               if success:
                   print "trajectory succeeded!"
               else:
                   print "trajectory failed."
            
               self.done_pub.publish(Empty())
            

if __name__ == "__main__":
    move_arm = MoveArm("goal","arm_done")
    move_arm.run()
    
