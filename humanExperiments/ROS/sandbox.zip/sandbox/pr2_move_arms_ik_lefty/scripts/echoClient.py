# Echo client program
import socket
import roslib
roslib.load_manifest('pr2_move_arms_ik')
import rospy
from pr2_move_arms_ik.srv import ExecuteCartesianIKTrajectory
from geometry_msgs.msg import Pose
from geometry_msgs.msg import Point
from geometry_msgs.msg import Twist
from std_msgs.msg import Empty
from threading import Lock
from pr2_move_arms_ik.msg import PickPlaceCmd
from nav_msgs.msg import Odometry

import time
import sys
import pdb
import tf
import math


class myClient:
	def __init__(self, cmd_topic, done_topic,base_topic,odom_topic):
		print 'Starting Node...'
        	rospy.init_node("interface_node")
		print 'Started.'

		print 'Connecting to Server...'
		HOST = '128.31.7.70'    	# The remote host
		PORT = 50001             # The same port as used by the server
		self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		self.s.connect((HOST, PORT))
		print '...Connected to Server.'	
	
		self.tf_listener = tf.TransformListener()
		time.sleep(.5) #give the transform listener time to get some frames
		
		#self.done_sub = rospy.Subscriber(cmd_topic, Pose, self.setPose, queue_size=1)
		self.goal_pub = rospy.Publisher(cmd_topic, PickPlaceCmd)
		self.base_pub = rospy.Publisher(base_topic, Twist)
		self.odometry_sub = rospy.Subscriber(odom_topic, Odometry, self.setOdom)

		self.base_position = Point()
		self.base_orientation = [0,0,1,0]
		self.base_z_rot = 0;
	
	def setOdom(self, msg):
		#print 'receivingOdom'
		self.base_position = msg.pose.pose.position

		#Convert quaternion to rotation about z-axis
		q0 = msg.pose.pose.orientation.x
		q1 = msg.pose.pose.orientation.y
		q2 = msg.pose.pose.orientation.z
		q3 = msg.pose.pose.orientation.w			
		self.base_phi = math.atan2(2*(q0*q1+q2*q3),1-2*(q1**2+q2**2))

		#print self.base_phi
		#print self.base_orientation

	def moveControlLoop(self,x_f,y_f,theta_f):
		moveCmd = Twist()
		
		#Correct Heading
		print 'Correcting Heading...'
		counter = 0
		dt = 0.001
		v_phi_o = 0
		while True:
			d_phi = math.atan2(y_f-self.base_position.y,x_f-self.base_position.x)-self.base_phi

#			if counter == 1000:
#				print 'd_phi'
#				print d_phi
#				counter = 0	
#			else:
#				counter = counter + 1	
			
			f_phi = 10*d_phi
			v_phi = v_phi_o + f_phi*dt

			if v_phi > 1:
				v_phi = 1	
			elif v_phi < -1:
				v_phi = -1

#			if v_phi > 0 and v_phi < .25:
#				v_phi = .25
#			elif v_phi < 0 and v_phi > -.25:
#				v_phi = -.25
			
			v_phi_o = v_phi

			if abs(d_phi) < .05:
				v_phi = 0
				moveCmd.angular.z = v_phi
				self.base_pub.publish(moveCmd)
				break
			
			moveCmd.angular.z = v_phi
			self.base_pub.publish(moveCmd)	

		#Correct Position
		print 'Correcting Position...'
		v_x_o = 0
		v_phi_o = 0
		b_x = .5
		b_phi = .5
		while True:
			d_x = (x_f-self.base_position.x)**2+(y_f-self.base_position.y)**2+(0-self.base_position.z)**2
			d_phi = math.atan2(y_f-self.base_position.y,x_f-self.base_position.x)-self.base_phi

			if d_phi > math.pi:
				d_phi = d_phi-2*math.pi
			elif d_phi < -math.pi:
				d_phi = d_phi+2*math.pi
		
			f_x = 1*d_x - b_x*v_x_o
			v_x = v_x_o + f_x*0.0001
			
			f_phi = 1*d_phi - b_phi*v_phi_o
			v_phi = v_phi_o + f_phi*0.0001
	
			
			if counter == 10000:
				print 'd_phi'
				print d_phi
				print 'f_phi'
				print f_phi
				print 'v_phi'
				print v_phi
				counter = 0	
			else:
				counter = counter + 1			

			if v_x > 1:
				v_x = 1	
			elif v_x < -1:
				v_x = -1

			if v_phi > 1:
				v_phi = 1	
			elif v_phi < -1:
				v_phi = -1

			if abs(d_phi) > .1:
				v_x = 0
				moveCmd.angular.z = v_phi
				moveCmd.linear.x = v_x
				self.base_pub.publish(moveCmd)
			elif abs(d_x) < .05**2:
				v_x = 0
				v_phi = 0
				moveCmd.linear.x = v_x
				moveCmd.angular.z = v_phi
				self.base_pub.publish(moveCmd)
				break
			else:
				moveCmd.angular.z = v_phi
				moveCmd.linear.x = v_x
				self.base_pub.publish(moveCmd)	

			v_x_o = v_x
			v_phi_o = v_phi
		

		
		#Correct Heading
		print 'Correcting Headings...'
		while True:
			d_phi = (theta_f-self.base_phi)
			vel = 1*d_phi
			if vel > 1:
				vel = 1	
			elif vel < -1:
				vel = -1

			if vel > 0 and vel < .25:
				vel = .25
			elif vel < 0 and vel > -.25:
				vel = -.25

			if abs(d_phi) < .05:
				moveCmd.angular.z = 0
				self.base_pub.publish(moveCmd)
				break
			
			moveCmd.angular.z = vel
			self.base_pub.publish(moveCmd)

#		moveCmd.linear.x = .25
#		counter = 0
#		while True:
#			self.base_pub.publish(moveCmd)
#			counter = counter + 1
#			time.sleep(.01) #give the transform listener time to get some frames
#			if counter > 1000:
#				break
#		
#		print 'turning'
#		moveCmd.linear.x = .0
#		moveCmd.angular.z = .75
#		counter = 0
#		while True:
#			self.base_pub.publish(moveCmd)
#			counter = counter + 1
#			time.sleep(.01) #give the transform listener time to get some frames
#			if counter > 1000:
#				break
#		print 'stopping'

	def run(self):
		while not rospy.is_shutdown():

		    	data = self.s.recv(1024)
			print 'Received', repr(data) 

			start_ind = data.find('{');
			end_ind = data.find('}');
			if start_ind > -1 and end_ind > -1:
				task = data[start_ind:end_ind+1]
				self.s.send(task)
				

				#Publish the move forward

				self.moveControlLoop(0,0,0)


				#Publish the command to pick_place
				myCmd = PickPlaceCmd()

				myCommand = "pick"				
				myPose = Pose()
				myPose.position.x = 0.5
				myPose.position.y = -0.7
				myPose.position.z = 0.6
				
				myCmd.cmd = myCommand
				myCmd.pose = myPose

				self.goal_pub.publish(myCmd)

				 
				

			elif data.find('exit') > -1:
				self.s.close();
				break;

if __name__ == "__main__":
    my_client = myClient("pickplace","pickplace_done","/base_controller/command","/base_odometry/odom")
    my_client.run()
