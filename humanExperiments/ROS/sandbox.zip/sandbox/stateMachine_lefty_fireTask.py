# Echo client program
PKG = "pr2_move_base"
import socket
import roslib
import roslib; roslib.load_manifest(PKG) 
import rospy
from std_msgs.msg import String
import actionlib
roslib.load_manifest('pr2_move_arms_ik_lefty')
import rospy
from pr2_move_arms_ik.srv import ExecuteCartesianIKTrajectory
from geometry_msgs.msg import Pose
from geometry_msgs.msg import Point
from geometry_msgs.msg import Twist
from geometry_msgs.msg import PoseStamped
from std_msgs.msg import Empty
from threading import Lock
from pr2_move_arms_ik.msg import PickPlaceCmd
from nav_msgs.msg import Odometry
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal, MoveBaseResult, MoveBaseFeedback, MoveBaseActionGoal

import rospy
import actionlib
from actionlib_msgs.msg import *
from pr2_controllers_msgs.msg import *
from geometry_msgs.msg import *

import time
import sys
import pdb
import tf
import math

class myClient:
	def __init__(self):
		print 'Starting Node...'
        	rospy.init_node("state_machine_node")

		print 'Creating Socket...'
		HOST = '128.31.7.51'    	# The remote host
		PORT = 7777             # The same port as used by the server
		self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		print 'Socket created. Connecting to server...'		
		self.s.connect((HOST, PORT))
		print '...Connected to Server.'	

		self.base_position = (0,0,0)
		self.base_vel_x = 0
		self.base_vel_y = 0
		self.base_vel_z = 0
		self.base_vel_phi = 0
		self.base_phi = 0

		self.max_lin_vel = .2
		self.max_ang_vel = .45

		self.receivingPoseUpdates = False
		self.time = rospy.get_time()
		self.pickPlaceStatus = 1

		self.pauseState = False

		#Topic to move the robot base
		self.base_pub = rospy.Publisher("/base_controller/command", Twist)
		#Topic to obtain the robot pose		
		self.odometry_sub = rospy.Subscriber("my_robot_pose", Pose, self.setPose)
		#Topic to pick/place
		self.arm_pub = rospy.Publisher("pickplace", PickPlaceCmd)
		#Topic to know when arm is done moving	
		self.arm_sub = rospy.Subscriber("pickplace_done",Empty, self.setPickPlaceStateInactive)
		#Topics to know if the robot needs to pause
		self.pause_sub = rospy.Subscriber("pause_channel",Empty, self.setPauseStateTrue)
		self.unpause_sub = rospy.Subscriber("unpause_channel",Empty, self.setPauseStateFalse)
		#Topics inspect part
		self.inspection_start_pub = rospy.Publisher("start_inspection",Empty)
		self.inspection_end_pub = rospy.Publisher("end_inspection",Empty)
		#Topic for robot sound
		self.sound_pub = rospy.Publisher('sound', String)

		#Topic to move the head
		self.head_client = actionlib.SimpleActionClient('/head_traj_controller/point_head_action', PointHeadAction)
		self.head_client.wait_for_server()

		print 'Started.'

	def setPickPlaceStateInactive(self, msg):

		self.pickPlaceStatus = 0

	def setPickPlaceStateActive(self):

		self.pickPlaceStatus = 1

	def setPauseStateTrue(self, msg):
		print 'Pausing'
		self.pauseState = True

	def setPauseStateFalse(self, msg):
		print 'Resuming'
		self.pauseState = False

	def setPose(self, msg):
	
		if self.receivingPoseUpdates:

			new_base_position = msg.position
			
			#Convert quaternion to rotation about z-axis
			q0 = msg.orientation.x
			q1 = msg.orientation.y
			q2 = msg.orientation.z
			q3 = msg.orientation.w			
			new_base_phi = math.atan2(2*(q0*q1+q2*q3),1-2*(q1**2+q2**2))

			old_time = self.time
			new_time = rospy.get_time()

			dt = new_time-old_time

			if dt > 0:
				self.base_vel_x = (new_base_position.x-self.base_position.x)/dt
				self.base_vel_y = (new_base_position.y-self.base_position.y)/dt
				self.base_vel_z = (new_base_position.z-self.base_position.z)/dt
				self.base_vel_phi = (new_base_phi-self.base_phi)/dt
				self.time = rospy.get_time()

			self.base_position = new_base_position
			self.base_phi = new_base_phi
		else:
			print 'receiving position'
			self.base_position = msg.position

			#Convert quaternion to rotation about z-axis
			q0 = msg.orientation.x
			q1 = msg.orientation.y
			q2 = msg.orientation.z
			q3 = msg.orientation.w			
			self.base_phi = math.atan2(2*(q0*q1+q2*q3),1-2*(q1**2+q2**2))
			self.time = rospy.get_time()

			self.receivingPoseUpdates = True

	def pickPart(self,y_g):
		#Pick the part
		print 'Picking Part'
		#dx = (.1-self.base_position.x)+(1-math.cos(0-self.base_phi))*.7
		#dy = (y_g - self.base_position.y)+math.sin(0 - self.base_phi)*.7
		myCmd = PickPlaceCmd()
		myCommand = "pick"				
		myPose = Pose()
		myPose.position.x = 0.6#+dx
		myPose.position.y = 0.3#+dy
		myPose.position.z = 0.7
		myCmd.cmd = myCommand
		myCmd.pose = myPose

		print "myCmd "+repr(myCmd.cmd)+" pose "+repr(myCmd.pose)

		#Point head towards part.
		g = PointHeadGoal()
		g.target.header.frame_id = 'base_link'
		g.target.point.x = .6
		g.target.point.y = .3
		g.target.point.z = .7
		g.min_duration = rospy.Duration(1.0)
		self.head_client.send_goal(g)
		self.head_client.wait_for_result()

		print "done pointing head"

		self.setPickPlaceStateActive()
		self.arm_pub.publish(myCmd)

		print "done publishing"
		#count=0
		#self.pickPlaceStatus = 0
		
		while (self.pickPlaceStatus == 1):# and count < 500):
			time.sleep(0.01)
			#count=count+1
			#print "in while loop"
		#print 'count '+repr(count)
		print 'Complete'

	def placePart(self):
		####   Place the part   ###
		print 'Placing part...'
		dx = 0#(.1-self.base_position.x)+(1-math.cos(0-self.base_phi))*.7
		dy = 0#(y_g - self.base_position.y)+math.sin(0 - self.base_phi)*.7
		myCmd = PickPlaceCmd()
		myCommand = "place"				
		myPose = Pose()
		myPose.position.x = 0.7
		myPose.position.y = 0.3-dx
		myPose.position.z = 0.8-dy
		myCmd.cmd = myCommand
		myCmd.pose = myPose
		self.setPickPlaceStateActive()
		self.arm_pub.publish(myCmd)

		while (self.pickPlaceStatus == 1):
			time.sleep(0.01)

	def moveControlLoop(self,x_f,y_f,theta_f):

		moveCmd = Twist()
		
		dt = 0.001
		
		k_x = 1
		k_theta = 7

		b_x = .5
		b_phi = 1.5

		i_phi = .1
		i_x = .1

		counter = 0
		v_phi_o = 0
		v_x_o = 0

		integral_phi = 0
		integral_x = 0

		#Point head forward.
		g = PointHeadGoal()
		g.target.header.frame_id = 'base_link'
		g.target.point.x = 1
		g.target.point.y = 0
		g.target.point.z = 1.3
		g.min_duration = rospy.Duration(1.0)
		self.head_client.send_goal(g)
		self.head_client.wait_for_result()

		#Correct Heading
		integral_phi = 0
		print 'Correcting Headings...'
		while True:

			while (self.pauseState == True):
				time.sleep(0.005)
				v_phi = 0
				v_phi_o = v_phi
				moveCmd.angular.z = v_phi
				self.base_pub.publish(moveCmd)

			time.sleep(0.005)

			d_x = math.sqrt((x_f-self.base_position.x)**2+(y_f-self.base_position.y)**2)
			d_phi = math.atan2(y_f-self.base_position.y,x_f-self.base_position.x)-self.base_phi
			if d_phi > math.pi:
				d_phi = d_phi-2*math.pi
			elif d_phi < -math.pi:
				d_phi = d_phi+2*math.pi
	
			integral_phi = integral_phi+d_phi*dt

			f_phi = k_theta*d_phi - b_phi*v_phi_o + i_phi*integral_phi
			v_phi = v_phi_o + f_phi*dt

			counter = counter + 1
			if counter == 1000:
				print ("phi = %s | d_phi = %s" % (round(self.base_phi),round(d_phi,3)))
				counter = 0	

			if v_phi > self.max_ang_vel:
				v_phi = self.max_ang_vel	
			elif v_phi < -self.max_ang_vel:
				v_phi = -self.max_ang_vel

			if abs(d_phi) < .025 or abs(d_x) < .02:
				v_phi = 0
				v_phi_o = v_phi
				moveCmd.angular.z = v_phi
				self.base_pub.publish(moveCmd)
				break

			v_phi_o = v_phi
			moveCmd.angular.z = v_phi
			self.base_pub.publish(moveCmd)
		
		#Correct Position
		integral_phi = 0
		integral_x = 0
		print 'Correcting Position...'
		while True:

			while (self.pauseState == True):
				time.sleep(0.005)
				v_x = 0
				v_phi = 0
				v_x_o = v_x
				v_phi_o = v_phi
				moveCmd.linear.x = v_x
				moveCmd.angular.z = v_phi
				self.base_pub.publish(moveCmd)

			time.sleep(0.005)

			d_x = math.sqrt((x_f-self.base_position.x)**2+(y_f-self.base_position.y)**2)

			d_phi = math.atan2(y_f-self.base_position.y,x_f-self.base_position.x)-self.base_phi
			if d_phi > math.pi:
				d_phi = d_phi-2*math.pi
			elif d_phi < -math.pi:
				d_phi = d_phi+2*math.pi

			integral_phi = integral_phi+d_phi*dt
			integral_x = integral_x+d_x*dt

			f_x = k_x*d_x - b_x*v_x_o + 0*i_x*integral_x
			v_x = v_x_o + f_x*dt
			#print (f_x,v_x)			

			f_phi = k_theta*d_phi - b_phi*v_phi_o + 0*i_phi*integral_phi
			v_phi = v_phi_o + f_phi*dt
	
			counter = counter + 1			
			if counter == 1000:
				print ("phi = %s | d_phi = %s | d_x = %s" % (round(self.base_phi),round(d_phi,3),round(d_x,3)))
				counter = 0

			if v_x > self.max_lin_vel:
				v_x = self.max_lin_vel
			elif v_x < -self.max_lin_vel:
				v_x = -self.max_lin_vel

			if v_phi > self.max_ang_vel:
				v_phi = self.max_ang_vel	
			elif v_phi < -self.max_ang_vel:
				v_phi = -self.max_ang_vel

			if abs(d_phi) > math.pi/8 and abs(d_x) > .025:

				v_x = 0
				moveCmd.angular.z = v_phi
				moveCmd.linear.x = v_x
				self.base_pub.publish(moveCmd)
			elif abs(d_x) <= .025:
				v_x = 0
				v_phi = 0
				v_x_o = v_x
				v_phi_o = v_phi
				moveCmd.linear.x = v_x
				moveCmd.angular.z = v_phi
				self.base_pub.publish(moveCmd)
				break
			else:
				moveCmd.angular.z = v_phi
				moveCmd.linear.x = v_x
				self.base_pub.publish(moveCmd)	

			v_x_o = v_x
			v_phi_o = v_phi
		
		#Correct Heading
		integral_phi = 0
		print 'Correcting Headings...'
		while True:

			while (self.pauseState == True):
				time.sleep(0.005)
				v_phi = 0
				v_phi_o = v_phi
				moveCmd.angular.z = v_phi
				self.base_pub.publish(moveCmd)

			time.sleep(0.005)

			d_phi = theta_f-self.base_phi
			if d_phi > math.pi:
				d_phi = d_phi-2*math.pi
			elif d_phi < -math.pi:
				d_phi = d_phi+2*math.pi
	
			integral_phi = integral_phi+d_phi*dt

			f_phi = k_theta*d_phi - b_phi*v_phi_o + i_phi*integral_phi
			v_phi = v_phi_o + f_phi*dt

			counter = counter + 1
			if counter == 1000:
				print ("phi = %s | d_phi = %s" % (round(self.base_phi),round(d_phi,3)))
				counter = 0	

			if v_phi > self.max_ang_vel:
				v_phi = self.max_ang_vel	
			elif v_phi < -self.max_ang_vel:
				v_phi = -self.max_ang_vel

			if abs(d_phi) < .02:
				v_phi = 0
				v_phi_o = v_phi
				moveCmd.angular.z = v_phi
				self.base_pub.publish(moveCmd)
				break

			v_phi_o = v_phi
			moveCmd.angular.z = v_phi
			self.base_pub.publish(moveCmd)

		print "Done."
	
	#def run(self):
	#	firstTime = 1
	#	while not rospy.is_shutdown():
	#		if firstTime == 1 and self.receivingPoseUpdates == 1:
	#			firstTime = 0
	#			print 'Ready to go...' 	

	def getFireName(self,action):
		if action.find('0') > -1:
			return 'Alpha'
		elif action.find('1') > -1:
			return 'Bravo'
		elif action.find('2') > -1:
			return 'Charlie'
		elif action.find('3') > -1:
			return 'Delta'
		elif action.find('4') > -1:
			return 'Echo'
		else:
			return 'None'

	def run(self):
		print 'Stopping Inspection...'
		firstTime = 1
		empty = Empty()
		self.inspection_end_pub.publish(empty)

		while not rospy.is_shutdown():
			if firstTime == 1: 
				if self.receivingPoseUpdates == 1:
					firstTime = 0
				else:
					continue
			#Read in from socket
			print 'Receiving...'
			data = self.s.recv(1024)
			print 'Received', repr(data) 

			print 'num tasks found: ',data.count('{')

			if data.find('exit') > -1:
				print 'Exiting'
				self.s.close();
				break;
			elif data.count('{') == 0:
				print 'Unreadable Message.'

			#If we received a task
			for i in range(0,data.count('{')):

				if i == 0:
					#Get the task name
					start_ind = data.find('{');
					end_ind = data.find('}');
					task = data[start_ind:end_ind+1]
					print 'Task: ',task
				else:
					last_ind = data.rfind('}')
					data = data[end_ind+1:last_ind+1]
					start_ind = data.find('{');
					end_ind = data.find('}');
					task = data[start_ind:end_ind+1]
					print 'Task: ',task	
		
				empty = Empty()
				
				self.s.send(task)

				robotAction=-1;
				humanAction=-1;
				
				if task.find('R') > -1:
					robotAction = task[task.find('R')+1]
				if task.find('H') > -1:
					humanAction = task[task.find('H')+1]

				if task.find('SUGGESTION') > -1:
					print 'I will extinguish '+self.getFireName(robotAction)+' and suggest you to extinguish '+self.getFireName(humanAction)
					self.sound_pub.publish('I will extinguish '+self.getFireName(robotAction)+' and suggest you to extinguish '+self.getFireName(humanAction))
				elif task.find('UPDATE') > -1:
					print 'I will extinguish '+self.getFireName(robotAction)
					self.sound_pub.publish('I will extinguish '+self.getFireName(robotAction))
				elif task.find('ACCEPT') > -1:
					print 'Yes, I accept' # your suggestion to extinguish '+self.getFireName(robotAction)
					self.sound_pub.publish('Yes, I accept') # your suggestion to extinguish '+self.getFireName(robotAction))
				elif task.find('REJECT') > -1:
					print 'No, I will extinguish '+self.getFireName(robotAction)+' instead'
					self.sound_pub.publish('No, I will extinguish '+self.getFireName(robotAction)+' instead')
				elif task.find('*') > -1:
					print '**Execute '+self.getFireName(robotAction)+'**'
					if task.find('**') > -1:
						self.sound_pub.publish('I will extinguish '+self.getFireName(robotAction))
					#Start event immediately
					
					x = 100
					y = 100
					z = 100
					#y_g_green = 0.9#.45+.15-.6
					
					print 'RobotAction '+robotAction

					if robotAction == '0':
						x=-.032
						y=1.347
						z=3.12
						#y_g=0+y_g_green
					elif robotAction == '1':
						x=-.04
						y=1.122
						z=3.11
						#y_g=.1+y_g_green
					elif robotAction == '2':
						x=-.036
						y=.878
						z=3.094
						#y_g=.2+y_g_green
					elif robotAction == '3':
						x=-.046
						y=.654
						z=3.083
						#y_g=.3+y_g_green
					elif robotAction == '4':
						x=-.056
						y=.378
						z=3.076
						#y_g=.4+y_g_green

					#print 'y'+repr(y)

					if x == 100 or y == 100 or z == 100: #or y_g_dropoff == 100:
						continue

					print 'y '+repr(y)
				
					#Move to pick.
					#self.moveControlLoop(.1,y_g,0)
					#self.moveControlLoop(.01,y,3.141)
					self.moveControlLoop(x,y,z)

					time.sleep(1.0)

					#Pick part.
					self.pickPart(y)

					#Verify Part.
					#empty = Empty()
					#self.inspection_start_pub.publish(empty)

					#Stop verification process
					#empty = Empty()
					#self.inspection_end_pub.publish(empty)	
					
					#Move to Place
					#self.moveControlLoop(.1,y_g_dropoff,3.141)

					#Place.
					#self.placePart()
					self.s.send("Done\n")
					print 'sent Done\n'

				#Acknowledge task completion.
				#self.s.send(task)
				#print 'sent message '+repr(task)

if __name__ == "__main__":
    my_client = myClient()
    my_client.run()

