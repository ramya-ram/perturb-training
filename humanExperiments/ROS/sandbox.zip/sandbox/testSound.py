#!/usr/bin/env python
import roslib;
import rospy, os, sys
from std_msgs.msg import String

def subscriber():
	pub = rospy.Publisher('sound', String)
	rospy.init_node('soundSubscriber', anonymous=True)
	pub.publish("Hello world")

if __name__ == '__main__': 
    try:
        subscriber()
    except rospy.ROSInterruptException: pass
